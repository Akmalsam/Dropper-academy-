
-- Dropper Academy production database schema
-- Run this in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.tests (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  chapter text,
  duration_minutes integer not null default 20,
  marks_per_correct integer not null default 4,
  negative_marks integer not null default 1,
  published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  test_id uuid not null references public.tests(id) on delete cascade,
  question_text text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_option integer not null check (correct_option between 0 and 3),
  explanation text,
  ncert_reference text,
  question_order integer not null default 1
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  test_id uuid not null references public.tests(id) on delete cascade,
  score integer not null default 0,
  correct_count integer not null default 0,
  wrong_count integer not null default 0,
  unattempted_count integer not null default 0,
  submitted_at timestamptz not null default now()
);

create table if not exists public.attempt_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  selected_option integer check (selected_option between 0 and 3),
  is_correct boolean not null default false
);

alter table public.profiles enable row level security;
alter table public.tests enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;
alter table public.attempt_answers enable row level security;

-- Students can read published tests/questions.
create policy "published tests readable"
on public.tests for select
to authenticated
using (published = true or created_by = auth.uid());

create policy "questions readable for published tests"
on public.questions for select
to authenticated
using (
  exists (
    select 1 from public.tests t
    where t.id = questions.test_id
      and (t.published = true or t.created_by = auth.uid())
  )
);

-- Students can see/create only their own attempts.
create policy "own attempts"
on public.attempts for all
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "own attempt answers"
on public.attempt_answers for all
to authenticated
using (
  exists(select 1 from public.attempts a where a.id = attempt_id and a.user_id = auth.uid())
)
with check (
  exists(select 1 from public.attempts a where a.id = attempt_id and a.user_id = auth.uid())
);

-- Profiles: users can read/update their own profile.
create policy "own profile read"
on public.profiles for select
to authenticated
using (id = auth.uid());

create policy "own profile update"
on public.profiles for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

-- IMPORTANT:
-- Admin write policies should be added only after setting up a secure admin-role
-- mechanism (for example a protected server-side function/claim).
-- Do NOT put a service_role key in browser code.
