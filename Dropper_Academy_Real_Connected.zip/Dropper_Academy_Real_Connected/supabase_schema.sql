-- Dropper Academy production starter schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.tests (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  chapter text not null default '',
  duration_minutes integer not null default 20 check (duration_minutes > 0),
  positive_marks integer not null default 4,
  negative_marks integer not null default 1,
  published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  test_id uuid not null references public.tests(id) on delete cascade,
  question_text text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_option integer not null check (correct_option between 0 and 3),
  explanation text not null default '',
  ncert_reference text not null default '',
  question_order integer not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  test_id uuid not null references public.tests(id) on delete cascade,
  score integer not null default 0,
  correct_count integer not null default 0,
  wrong_count integer not null default 0,
  unattempted_count integer not null default 0,
  submitted_at timestamptz not null default now()
);

create table if not exists public.attempt_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  selected_option integer check (selected_option between 0 and 3),
  is_correct boolean not null default false,
  unique(attempt_id, question_id)
);

-- Create a profile automatically after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Admin helper avoids putting any secret/service-role key in the browser.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.tests enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;
alter table public.attempt_answers enable row level security;

-- Profiles
 drop policy if exists "profile own read" on public.profiles;
create policy "profile own read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());

 drop policy if exists "profile own update" on public.profiles;
create policy "profile own update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Tests: students see only published tests; admins can manage all.
drop policy if exists "published tests read" on public.tests;
create policy "published tests read" on public.tests for select to authenticated using (published = true or public.is_admin());

drop policy if exists "admin tests insert" on public.tests;
create policy "admin tests insert" on public.tests for insert to authenticated with check (public.is_admin() and created_by = auth.uid());

drop policy if exists "admin tests update" on public.tests;
create policy "admin tests update" on public.tests for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin tests delete" on public.tests;
create policy "admin tests delete" on public.tests for delete to authenticated using (public.is_admin());

-- Questions: students can read questions only for published tests; admins manage.
drop policy if exists "published questions read" on public.questions;
create policy "published questions read" on public.questions for select to authenticated
using (exists (select 1 from public.tests t where t.id = test_id and (t.published = true or public.is_admin())));

drop policy if exists "admin questions insert" on public.questions;
create policy "admin questions insert" on public.questions for insert to authenticated with check (public.is_admin());

drop policy if exists "admin questions update" on public.questions;
create policy "admin questions update" on public.questions for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin questions delete" on public.questions;
create policy "admin questions delete" on public.questions for delete to authenticated using (public.is_admin());

-- Attempts and answers belong to the logged-in student; admins can inspect them.
drop policy if exists "own attempts read" on public.attempts;
create policy "own attempts read" on public.attempts for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "own attempts insert" on public.attempts;
create policy "own attempts insert" on public.attempts for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "own answers read" on public.attempt_answers;
create policy "own answers read" on public.attempt_answers for select to authenticated using (
  exists (select 1 from public.attempts a where a.id = attempt_id and (a.user_id = auth.uid() or public.is_admin()))
);

drop policy if exists "own answers insert" on public.attempt_answers;
create policy "own answers insert" on public.attempt_answers for insert to authenticated with check (
  exists (select 1 from public.attempts a where a.id = attempt_id and a.user_id = auth.uid())
);

-- IMPORTANT: after creating your own account, make that account admin ONCE from SQL Editor:
-- update public.profiles set role='admin' where id = (select id from auth.users where email='YOUR_EMAIL');
